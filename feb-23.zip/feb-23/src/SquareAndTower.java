import java.util.Scanner;

public class SquareAndTower {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int cityLength=sc.nextInt();
		int noOfTowers=sc.nextInt();
		int towers[][]=new int[noOfTowers][2];
		int city[][]=new int[cityLength][cityLength];			//by default, every element is 0
		for(int i=0;i<noOfTowers;i++)
		{
			//no need for loop that iterates 2 times
			int x=sc.nextInt();
			int y=sc.nextInt();
			towers[i][0]=x;
			towers[i][1]=y;
		}
		//algorithm starts here
		//update the locations where towers are present. and their adjacent locations also by "1"
		for(int i=0;i<noOfTowers;i++)
		{
			int x=towers[i][0];
			int y=towers[i][1];
			
			//update city [x][y] as 1			also their adjacent locations too
			city[x][y]=1;
			
			//for adjacent locations
			//				x-1		x+1		when x-1, do all combinations of y-1	y+1 also		do it in loop
//			System.out.println("For the tower at "+x+":"+y);
			for(int a=-1;a<=1;a++)
			{
				//		a becomes 	-1, 0, +1
				for(int b=-1;b<=1;b++)
				{
					//		b becomes 	-1, 0, +1
					
					int newX=x+a;
					int newY=y+b;
//					System.out.printf("x=%d and y=%d\n",newX,newY);
					if(newX>=0 && newY>=0 && newX<cityLength && newY<cityLength)
						city[newX][newY]=1;
				}
//				System.out.println();
			}
			
		}
		//lets instead of display the city matrix, lets count the 0s
		int zerosCount=0;
		for(int i=0;i<cityLength;i++)
		{
			for(int j=0;j<cityLength;j++)
			{
				if(city[i][j]==0)
					zerosCount++;
			}
		}
		if(zerosCount>0)
		{
			System.out.println("No");
			System.out.println(zerosCount);
		}else
			System.out.println("Yes");
	}

}
