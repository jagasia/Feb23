
public class Casting2 {
	public static void main(String[] args) {
		float f=12;
		int i=100;
		f=i;			//this is nothing lost. so implicit casting
		System.out.println(f);
		i=(int) f;		//explicit
	}
}
