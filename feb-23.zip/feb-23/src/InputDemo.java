import java.util.Scanner;

public class InputDemo {

	public static void main(String[] args) {
		int i=0;
		float f=0;
		String str="";
		int age=0;
		Scanner sc=new Scanner(System.in);
		Scanner sc2=new Scanner(System.in);
		i=sc.nextInt();
		f=sc.nextFloat();
		str=sc2.nextLine();
//		if(str.equals(""))
//			str=sc.nextLine();
		age=sc.nextInt();
		
		System.out.println(i);
		System.out.println(f);
		System.out.println(str);
		System.out.println(age);
		
	}

}
