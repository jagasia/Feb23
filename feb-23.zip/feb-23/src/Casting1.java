
public class Casting1 {

	public static void main(String[] args) {
		int i=20;
		long l=30;
		l=i;				//i did not do casting explicitly. Here it happened implicitly
		//the above is an example for implicit casting
		System.out.println(l);
		i=(int) l;				//not implicit			//narrowing is not implicit
		//long is bigger than int. so it will not implicitly cast. 
	}

}
