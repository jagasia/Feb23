import java.util.Arrays;
import java.util.Scanner;

public class AnagramTask {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		String str1=sc.nextLine();
		String str2=sc.nextLine();
		if(str1.equals(str2))
		{
			System.out.println("They are anagrams");			
		}
		else if(str1.length()!=str2.length())
		{
			System.out.println("They are not anagrams");
		}else
		{
			char[] carr1 = str1.toCharArray();
			char[] carr2 = str2.toCharArray();
			Arrays.sort(carr1);
			Arrays.sort(carr2);
			str1=new String(carr1);			//char array to String
			str2=new String(carr2);
			if(str1.equals(str2))
				System.out.println("THey are aNagrams");
			else
				System.out.println("Not anagrams");
		}
	}

}
