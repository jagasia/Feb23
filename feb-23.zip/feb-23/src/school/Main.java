package school;

import college.Teacher;

public class Main {

	public static void main(String[] args) {
		Teacher rama=new Teacher();
//		rama.name="Ramakrishna";		//not able to access name because, Teacher belongs to someother package
		
	}

}
