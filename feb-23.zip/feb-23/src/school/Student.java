package school;

public class Student {

}
