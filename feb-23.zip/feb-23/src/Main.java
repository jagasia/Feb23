import java.text.ParseException;
import java.util.Date;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) throws ParseException {
		Student rama=new Student();
		rama.setStudentId(123);
		rama.setName("Rama");
		rama.setDateOfBirth1("1998-05-04");
		rama.setStd(9);
		System.out.println(rama.getDateOfBirth());
		Scanner sc=new Scanner(System.in);
	}

}
