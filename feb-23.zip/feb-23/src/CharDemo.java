import java.util.Scanner;

public class CharDemo {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		char c=sc.next().charAt(0);					//String has a method charAt(index)		since only 1 char is input, index is 0
//		System.out.println(c);
		//how to check if the input character is a number?
//		if(c>='0' && c<='9')
//			System.out.println("Number");
//		else if(c>='a' && c<='z')
//			System.out.println("Lower case character");
//		else if(c>='A' && c<'Z')
//			System.out.println("Upper case character");
//		else
//			System.out.println("Symbol");
		if(Character.isLetter(c))
			System.out.println("Letter");
		else if(Character.isDigit(c))
			System.out.println("Digit");
		
	}

}
