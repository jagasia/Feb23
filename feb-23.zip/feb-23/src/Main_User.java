import java.util.Scanner;

public class Main_User {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter user 1 detail:");
		String detail1=sc.nextLine();
		System.out.println("Enter user 2 detail:");
		String detail2=sc.nextLine();
		
		//split detail1 by ,
		String[] arr1 = detail1.split(",");
		User user1=new User();
		user1.setName(arr1[0]);
		user1.setEmail(arr1[1]);
		user1.setPhoneNumber(arr1[2]);
		user1.setLocation(arr1[3]);
		
		String[] arr2 = detail2.split(",");
		User user2=new User();
		user2.setName(arr2[0]);
		user2.setEmail(arr2[1]);
		user2.setPhoneNumber(arr2[2]);
		user2.setLocation(arr2[3]);
		
		if(user1.equals(user2))
			System.out.println("User 1 is same as User 2");
		else
			System.out.println("User 1 and User 2 are different");
	}

}
