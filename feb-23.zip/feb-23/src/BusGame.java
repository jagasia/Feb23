import java.util.Scanner;

public class BusGame {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int noOfKids=sc.nextInt();
		int x=sc.nextInt();
		String input="";
		int kidNo=1;
		do
		{
			input=sc.next();
//			System.out.println(""+kidNo+" says "+input);
//			if(input=="Bus")		//wrong
			if(!input.equals("Bus"))
			{
				int i=Integer.parseInt(input);		//convert String into int
				if(i%x==0)
				{
//					System.out.println(kidNo+" did the mistake");
					break;			//terminate the loop
				}
			}
			kidNo++;		//this increment may cause it go beyond noOfKids
			if(kidNo>noOfKids)
				kidNo=1;
		}while(true);
		System.out.println(kidNo);
	}

}
