import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

public class Main_Contact {

	public static void main(String[] args) throws ParseException {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter contact 1 detail:");
		String detail1=sc.nextLine();
		System.out.println("Enter contact 2 detail:");
		String detail2=sc.nextLine();
		
		String[] arr1 = detail1.split(",");
		Contact contact1=new Contact();
		contact1.setName(arr1[0]);
		contact1.setMobileNumber(arr1[1]);
		contact1.setMailId(arr1[2]);
		
		//			arr1[3] is a dob string. To convert String into Date, we need SimpleDateFormat
		SimpleDateFormat sdf=new SimpleDateFormat("dd/MM/yyyy");
		Date dob1 = sdf.parse(arr1[3]);
		
		contact1.setDob(dob1);
		
		//////////////////do the same for Contact 2
		
		String[] arr2 = detail2.split(",");
		Contact contact2=new Contact();
		contact2.setName(arr2[0]);
		contact2.setMobileNumber(arr2[1]);
		contact2.setMailId(arr2[2]);
		
		Date dob2 = sdf.parse(arr2[3]);
		
		contact2.setDob(dob2);
		
		///////compare if both contacts are same or not
		
		if(contact1.equals(contact2))
			System.out.println("Contact 1 is same as Contact 2");
		else
			System.out.println("Contact 1 and Contact 2 are different");
		
		
	}

}
