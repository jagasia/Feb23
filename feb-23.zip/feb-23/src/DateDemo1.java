import java.text.SimpleDateFormat;
import java.util.Date;

public class DateDemo1 {

	public static void main(String[] args) {
		Date dt1=new Date();
		SimpleDateFormat sdf=new SimpleDateFormat("yyyy");
		System.out.println(sdf.format(dt1));
		//to convert String into Date, 			use sdf.parse()method
		
	}

}
