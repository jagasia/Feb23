
public class WrapperDemo {

	public static void main(String[] args) {
		int i=20;
		Integer a=i;					//this is auto-boxing		
		i=a;							//this is auto unboxing
		
	}

}
