
public class Check {

	public static void main(String[] args) {
		int i=5;
		int j=9;
		System.out.println((float)i/j);
	}

}
