package college;

public class Teacher {
	String name;			//is it public or private? No. It is default scope which is package scope
}
