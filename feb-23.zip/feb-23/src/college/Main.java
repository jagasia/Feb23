package college;

public class Main {

	public static void main(String[] args) {
		Teacher rama=new Teacher();
		rama.name="ramakrishna";			//able to access name here, because, Main class is also present in the same package as Teacher
		int i=20;
		System.out.println(Integer.MAX_VALUE);
		final int X;
		X=20;
		
	}

}
