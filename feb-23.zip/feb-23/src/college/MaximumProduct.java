package college;

import java.util.Arrays;
import java.util.Scanner;

public class MaximumProduct {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		int arr[]=new int[n];
		for(int i=0;i<n;i++)
		{
			arr[i]=sc.nextInt();			
		}

		//loop the array take current element and multiply with all elements in the array
		int maxProduct=-1;
		for(int i=0;i<n;i++)
		{
			for(int j=i+1;j<n;j++)
			{

				//					System.out.printf("i=%d and j=%d\n",i,j);
				int product=arr[i]*arr[j];
				//check if product is found in the array list???
				for(int k=0;k<n;k++)
				{
					if(product==arr[k])
					{
						//it is found... but is this the maxProduct?
						if(product>maxProduct)
							maxProduct=product;
//						System.out.println("Max product is "+maxProduct);
					}
				}


			}
		}
		System.out.println(maxProduct);
	}

}
