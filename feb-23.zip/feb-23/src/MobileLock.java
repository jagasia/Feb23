import java.util.Scanner;

public class MobileLock {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int sideLength=sc.nextInt();
		int noOfPoints=sc.nextInt();				//5
		int [][]points=new int[noOfPoints][2];
		for(int i=0;i<noOfPoints;i++)
		{
			int x=sc.nextInt();			//nextInt() delimiter can be space or new line
			int y=sc.nextInt();
			points[i][0]=x;
			points[i][1]=y;	
			
		}
		//algorithm starts here
		//walk through the points
		int x1, y1;
		x1=points[0][0];
		y1=points[0][1];
		for(int i=1;i<noOfPoints;i++)			//1 to 4 that means 1 lesser than noOfPoints
		{
			//if noOfPoints is 5, then this for loop exectues 5 iterations
			int x2=points[i][0];
			int y2=points[i][1];
			
			//compare x1 with x2
			//compare y1 with y2
			int xDiff=Math.abs(x2-x1);
			int yDiff=Math.abs(y2-y1);
			if(xDiff>1 || yDiff>1)
			{
				System.out.println("Invalid");
				return;
			}
			x1=x2;
			y1=y2;
		}
		//find the coverage %		noOfPoint/(sideLength*sideLength)
		float coverage=(float)noOfPoints/(sideLength*sideLength);					//0.55 comes as 0
		coverage*=100;
		if(coverage>75)
			System.out.println("Excellent");
		else if(coverage>50)
			System.out.println("Good");
		else if(coverage>25)
			System.out.println("Average");
		else
			System.out.println("Poor");
	}

}
