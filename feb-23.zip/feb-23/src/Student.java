import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Student {
	private int studentId;
	private String name;
	private Date dateOfBirth;
	private int std;
	
	public Student() {}
	public Student(int studentId, String name, Date dateOfBirth, int std) {
		super();
		this.studentId = studentId;
		this.name = name;
		this.dateOfBirth = dateOfBirth;
		this.std = std;
	}
	public int getStudentId() {
		return studentId;
	}
	public void setStudentId(int studentId) {
		this.studentId = studentId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Date getDateOfBirth() {
		return dateOfBirth;
	}
	public String getDateOfBirth1()
	{
		SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd");
		return sdf.format(this.dateOfBirth);
	}
	public void setDateOfBirth(Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	public void setDateOfBirth1(String dob) throws ParseException
	{
		SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd");
		this.dateOfBirth=sdf.parse(dob);
	}
	public int getStd() {
		return std;
	}
	public void setStd(int std) {
		this.std = std;
	}
	@Override
	public String toString() {
		return "Student [studentId=" + studentId + ", name=" + name + ", dateOfBirth=" + getDateOfBirth1() + ", std=" + std
				+ "]";
	}
	
}
