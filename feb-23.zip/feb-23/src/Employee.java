
public class Employee 
{
	private int employeeId;			//if we make variable as public, we allow unconditionally
	private String firstName;
	private String lastName;
	private int departmentId;
	private int age;
	//to allow age to be accessible
	public void setAge(int age)
	{
		this.age=age;		//this is an object of current class
	}
	public int getAge()
	{
		return this.age;
	}
	public int getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
}
