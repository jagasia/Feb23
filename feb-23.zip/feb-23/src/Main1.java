
public class Main1 {

	public static void main(String[] args) {
		int a=20;			//I do not use L like 20L because, by dfault it is int
		float b=30.56f;	//if f is not used, then it is double by default
		a=(int) b;			//b is float and how to store it in a?
		//if you force to store float in int, we loose precision
		System.out.println(a);
		String str="10";
//		a=(int)str;		//not allowed
		
	}

}
