import java.util.Scanner;

public class CommonElementInMatrix {

	public static void main(String[] args) {
		int arr[][]=new int[4][4];
		Scanner sc=new Scanner(System.in);
		for(int i=0;i<4;i++)
		{
			for(int j=0;j<4;j++)
			{
				arr[i][j]=sc.nextInt();
			}
		}
		boolean isFound = false;
		int found=-1;
		for(int a=0;a<4;a++)			//first row
		{
			int firstRowElement=arr[0][a];			//0 is the index of first row anyway
			for(int i=1;i<4;i++)		//second row onwards
			{
				//row
				isFound = false;
				for(int j=0;j<4;j++)
				{
					//column
					if(firstRowElement==arr[i][j])
					{
						isFound=true;
						//it is found anywhere in the row, why comparing next colum?????
						break;	//break will break only the columns of current row.
					}else if(firstRowElement<arr[i][j])
						break;					
				}
				if(!isFound)
				{
					//it is not found in one row. so why proceed to next row?????
					break;
				}
			}
			if(isFound)
			{
				found=firstRowElement;
			}
			
		}
		System.out.println(found);
	}

}
